from flask_app.config.mysqlconnection import MySQLConnection, connectToMySQL

class Account:
    def __init__( self , data ):
        self.id = data['id']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.password_confirmation = data['password_confirmation']

@classmethod
def save(cls,data):

        query = "INSERT INTO accounts (email, password) VALUES ( %(email)s, %(password)s,);"
        t = connectToMySQL('accounts').query_db(query,data)
        print(t)
        return t

@classmethod
def get_all(cls):
    query = "SELECT * FROM accounts"
    results = MySQLConnection('accounts').query_db(query)