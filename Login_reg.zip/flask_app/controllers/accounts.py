from flask_app import app
from flask_bcrypt import Bcrypt
from flask import render_template, redirect, request, session, flash
from flask_app.models.account import Account
bcrypt = Bcrypt(app)

@app.route('/register', methods=['POST'])
def register():
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)

    data = {
        "email": request.form['email'],
        "password": pw_hash
    }

    account_id = Account.save(data)
    session[account_id]= account_id
    return redirect ('/logout')

@app.route('/login', methods=['POST'])
def login():
    data = {"email" : request.form["email"]}
    account_in_db = Account.get_by_email(data)

    if not account_in_db:
        flash("Invalid Email/Password")
        return redirect ('/')
    if not bcrypt.check_password_hash(account_in_db.password, request.form['password']):
        flash("Invalid Email/Password")
        return redirect('/')
    session['account_id'] = account_in_db.id
    return redirect ('/')

@app.route('/')
def home():
    return render_template('register_login.html')