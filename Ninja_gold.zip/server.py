# from re import X

# from flask import Flask, render_template

# app = Flask(__name__)                    



# @app.route('/play')                          

# def lvl1():

#     return render_template('index.html')




# @app.route('/play/<int:x>')                          

# def lvl2(x):    

#     return render_template("index2.html",x=x)



# @app.route('/play/<int:x>/<string:color>')                          

# def lvl3(x,color):    

#     return render_template("index2.html",x=x, color=color)




# if __name__=="__main__":

#     app.run(debug=True)  

# from flask import Flask, render_template

# app = Flask(__name__,)

# @app.route('/lists')
# def render_lists():
    
#     users = [
#     {'first_name' : 'Michael', 'last_name' : 'Choi'},
#     {'first_name' : 'John', 'last_name' : 'Supsupin'},
#     {'first_name' : 'Mark', 'last_name' : 'Guillen'},
#     {'first_name' : 'KB', 'last_name' : 'Tonel'}
# ]


#     return render_template("lists.html", student = users)

#     if __name__=="__main__":
#         app.run(debug=True)
# 
# 
# from flask import Flask, render_template, request, redirect, session

# app = Flask(__name__)
# app.secret_key = 'keep it secret, keep it safe' # set a secret key for security purposes

# @app.route('/destroy_session', methods=['get'])
# def reset_sesh():
#     session.clear()
#     return redirect('/')


# @app.route('/')
# def times():
#     if "count" not in session:
#         session["count"]=0
#         print(session["count"])
#         session["count"]+=1
#         print(session["count"])
#     return render_template('counter.html',count=session["count"])

# if __name__ == "__main__":
#     app.run(debug=True)

# from flask import Flask, render_template, request, redirect, session
# app = Flask(__name__)
# app.secret_key = 'keep it on the low'
# # our index route will handle rendering our form

    
            
# @app.route('/process', methods=['GET'])
# def steps():
#     session['name'] = request.form['name']
#     session['location'] = request.form['location']
#     session['language'] = request.form['language']
#     session['comments'] = request.form['comments']
#     return redirect('/result')



# @app.route('/')
# def index():
#     return render_template("dojo_survey.html")

# @app.route('/result', methods=['POST'])
# def finish():
#     return render_template("finish.html")
    
# if __name__ == "__main__":
#         app.run(debug=True)
import random
from flask import Flask, render_template, request, redirect, session
app = Flask(__name__)
app.secret_key = 'keep it on the low'

@app.route('/process_money', methods=['POST'])
def currency():
    print(request.form)

    if request.form['building']== 'farm':
        session['gold'] +=random.randrange(10,21)
    if request.form['building']== 'cave':
        session['gold'] +=random.randrange(5, 11)
    if request.form['building']== 'house':
        session['gold'] +=random.randrange(2, 6)
    if request.form['building']== 'casino':
        session['gold'] +=random.randrange(-50, 51)

    return redirect ('/')

@app.route('/', methods = ['GET'])
def collect():
    if "gold" not in session:
        session['gold'] = 0
    print(session)
    return render_template('ninja_gold.html', gold = session['gold'])

if __name__ == '__main__':
	app.run(debug=True)
    
     










