function message() {
    alert("Your Cart is empty!")
}

function disappear() {
    var element= document.querySelector('.cookie');
    element.remove();
}

function change(element) {

    if(element.getAttribute("src") == "succulents-2.jpg") {
        element.setAttribute("src", "succulents-1.jpg")
    }
    else{element.setAttribute("src", "succulents-2.jpg")}
}
