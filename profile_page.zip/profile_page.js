function disappear() {
    var element= 
document.querySelector('.user-line');
    element.remove();
}

function change() {
    var element= document.querySelector('.username')
    if(element.innerText== "Sprint Ravers"){element.innerText = "Vybz Kartel"}

    else{element.innerText= "Beenie Man"}
}

function up() {
    var element= document.querySelector('.connections')
    element.innerText++;
}

function down() {
    var element= document.querySelector('.connects')
    element.innerText--;
}

