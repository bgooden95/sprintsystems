var num = document.querySelectorAll("#count");
console.log(num)
console.log(num[0].innerText)
console.log(num[1].innerText)
console.log(num[2].innerText)


function like(id){
    num[id].innerText++;
}