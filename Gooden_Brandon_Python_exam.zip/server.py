from flask_app import app
from flask_app.controllers.Sellers import Seller, Car
from flask_app.models.Seller_model import Seller
from flask_app.models.Cars import Car
from flask_bcrypt import Bcrypt
bcrypt = Bcrypt(app)













if __name__ == '__main__':
	app.run(debug=True, port=5001)














