from flask_app.config.mysqlconnection import MySQLConnection, connectToMySQL
from flask import flash
db = 'cars'



class Car:

    def __init__( self , data ):
        self.id = data['id']
        self.model = data['model']
        self.year = data['year']
        self.make= data['make']
        self.price= data['price']
        self.description= data['description']
        





    @classmethod
    def get_all(cls):
        query = "SELECT * from cars"
        results = MySQLConnection(db).query_db(query)
        cars = []
        for car in results:
            cars.append(cls(car))
        return cars

    @classmethod
    def showing(cls,id):
        query = "SELECT * from cars WHERE id = %(id)s"
        results = connectToMySQL(db).query_db(query,{'id':id})
    # make sure to call the connectToMySQL function with the schema you are targeting.
        return cls(results[0])
        


    @classmethod
    def save(cls,data,id):
        query = f"INSERT INTO cars (model, year, make, price, description, sellers_id) VALUES (%(model)s , %(year)s ,%(make)s, %(price)s,%(description)s,{id});"
        return connectToMySQL(db).query_db(query,data)
    
    @classmethod
    def update(cls,data):
        query = "UPDATE cars SET model = %(model)s,year = %(year)s, make = %(make)s, price = %(price)s, description = %(description)s WHERE id = %(id)s"
        results = connectToMySQL(db).query_db(query, data)
        print(results)
        return results

    @classmethod
    def delete(cls,id):
        query = "DELETE FROM cars WHERE id = %(id)s"
        return connectToMySQL(db).query_db(query,id)

    
    @staticmethod
    def validate_new(form):
        print(form)
        is_valid = True
        if len(form['model']) < 3:
            flash("Model must be at least 3 characters.")
            is_valid = False
        if len(form['year']) < 3:
            flash("Year must be greater than 0.")
            is_valid = False
        if len(form['make']) < 3:
            flash("Make must be more than 3 characters.")
            is_valid = False
        if len(form['price']) < 3:
            flash("Price must be greater than 0.")
            is_valid = False
        if len(form['description']) < 3:
            flash("Description must be more than 3 characters.")
            is_valid = False
        print(is_valid)
        return is_valid