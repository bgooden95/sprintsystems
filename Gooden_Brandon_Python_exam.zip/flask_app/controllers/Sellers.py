from flask_app import app
from flask_bcrypt import Bcrypt
from flask import render_template, redirect, request, session, flash
from flask_app.models.Seller_model import Seller 
from flask_app.models.Cars import Car
bcrypt = Bcrypt(app)

@app.route('/register', methods=['POST'])
def register():
    print(request.form)

    if not Seller.validate_register(request.form):
        return redirect ('/')

    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "password": bcrypt.generate_password_hash(request.form['password'])
    }
    
    id=Seller.save(data)
    session["id"]= id
    return redirect ('/')

@app.route('/login', methods=['POST'])
def login():
    data = { "email" : request.form["email"],"password" : request.form["password"] }
    seller_account = Seller.get_by_email(data)
    if not seller_account:
        flash("No user found")
        return redirect("/")
    if not bcrypt.check_password_hash(seller_account.password, request.form['password']):
        flash("Invalid Password")
        return redirect('/')
    session['id'] = seller_account.id
    return redirect('/cars')

@app.route('/')
def home():
    return render_template('register_login.html')

@app.route('/logout')
def logout():
    session.clear
    return redirect('/')

@app.route('/cars')
def cars():
    t = Car.get_all()
    # viewers = Viewer.get_all()
    # print(viewers)
    print(t)
    return render_template('cars.html', t=t)

@app.route('/cars/new')
def new_car():
    return render_template('new_car.html')

@app.route('/cars/create', methods=['POST'])
def save():
    if not Car.validate_new(request.form):
        return redirect('/cars/new')
    id=session["id"]
    Car.save(request.form,id)
    return redirect('/cars')




@app.route('/cars/<int:id>/destroy')
def delete(id):
    dell = {'id':id}
    Car.delete(dell)
    return redirect('/cars')


# @app.route('/users/update', methods=['POST'])
# def update():
#     data ={
#     "name": request.form["name"],
#     "email" : request.form["email"]
#     }
#     User.update(data)
#     return redirect('/')





@app.route('/cars/<int:id>/edit')
def editing(id):
    x = Car.showing(id)
    print(x)
    return render_template('edit_car.html',x=x) 

@app.route('/cars/<int:id>/display')
def show(id):   
    card = Car.showing(id)
    print(card)
    return render_template('confirmation.html',card=card)

@app.route('/cars/<int:id>/update', methods=['POST'])
def update(id):
    data ={
    "id": id,
    "model": request.form["model"],
    "year": request.form["year"],
    "make" : request.form["make"],
    "price" : request.form["price"],
    "description" : request.form["description"]
    }
    Car.update(data)
    return redirect('/cars')