function message() {
    alert("Loading weather report...")
}

function disappear() {
    var element= document.querySelector('.cookie');
    element.remove();
    

}

function toCel(degree) {
    return Math.round(9 / 5 * degree + 32);
}

function toFaren(degree) {
    return Math.round(5 / 9 * (degree - 32));
}

function chooseDegree(element) {
    console.log(element.value);
    for(var i=1; i<9; i++) {
        var degreeSpan = document.querySelector("#degree" + i);
        var degreeVal = parseInt(degreeSpan.innerText);
        if(element.value == "°C") {
            degreeSpan.innerText = toFaren(degreeVal);
        } else {
                degreeSpan.innerText = toCel(degreeVal);
            }
        }
    }


